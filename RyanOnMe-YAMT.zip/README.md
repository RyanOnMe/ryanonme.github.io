# Ryan 的 GitHub Pages 主页

基于 [YAMT](https://github.com/PandaSekh/Jekyll-YAMT) 的 Jekyll 个人站点。首页展示 Ryan 的简介和 WhalePod、PRism、Loki 三个项目。上游许可证位于 `LICENSE.txt`，页脚保留原作者署名。

## 发布

1. 在 RyanOnMe 账号下创建公开仓库 `ryanonme.github.io`。
2. 解压后把本目录内的文件与文件夹提交到仓库的 `main` 分支根目录。确保 `index.html` 和 `_config.yml` 直接位于根目录。
3. 在仓库的 **Settings → Pages** 中选择 **Deploy from a branch**，选择 **main** 和 **/(root)**，点击 **Save**。
4. 部署完成后访问 [ryanonme.github.io](https://ryanonme.github.io/)。

## 编辑

- 姓名、站点地址和页面说明在 `_config.yml`。
- 页头副标题与导航在 `_data/settings.yml` 和 `_data/pages.yml`。
- 简介在 `index.html`，项目在 `_data/projects.yml`，封面图在 `assets/img/`。
- 首页沿用 YAMT 的图文列表结构，样式补充在 `_sass/classic.scss`。
